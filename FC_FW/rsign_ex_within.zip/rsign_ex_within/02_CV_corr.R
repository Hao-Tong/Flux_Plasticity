### Correlation coefficient checking! 
### Further information: tonghao0605@gmail.com

#dir <- "/winmounts/tong/winhome/mpidir/8.AlleleFlux/00_GxE/FC_FW/rsign_ex"
dir <- "H:/mpidir/8.AlleleFlux/00_GxE/FC_FW"
setwd(dir)

#####################################################################

fwdata <- read.table("../araid67_final_new_env.csv",head=F,sep=",")[,2:4]
pheno_opt <- as.matrix(fwdata[,1])
pheno_ln <- as.matrix(fwdata[,2])
pheno_lc <- as.matrix(fwdata[,3])

idsall <- read.table("foldid.csv",sep=",",header=F)

#####################################################################

corrall <- NULL
for (t in 1:50){
for (p in 1:3){

	ff <- read.table(paste("rsign_ex_within/steady-state_flux_LN_f",t,"_r",p,".csv",sep=""),sep=",",header=F)[336,]
	ff <- as.numeric(ff)

	fid <- idsall[,t]
	ids <- which(fid==p)
	bioms <- pheno_lc[ids]

	corr1 <- cor(bioms,ff,method="pearson",use="complete.obs") 
	corr2 <- cor(bioms,ff,method="spearman",use="complete.obs") 
	
	corrall <- rbind(corrall,cbind(corr1,corr2))
}
}

corm <- c(mean(corrall[,1],na.rm=T),mean(corrall[,2],na.rm=T))
corrall <- rbind(corrall,corm)

write.table(corrall,"rsign_ex_within/FW_corr_LN_new.csv",sep=",",row.names=F,col.names=F)

#####################################################################
#####################################################################
#####################################################################

corrall <- NULL
for (t in 1:50){
  for (p in 1:3){
    
    ff <- read.table(paste("rsign_ex_within/steady-state_flux_LC_f",t,"_r",p,".csv",sep=""),sep=",",header=F)[336,]
    ff <- as.numeric(ff)
    
    fid <- idsall[,t]
    ids <- which(fid==p)
    bioms <- pheno_lc[ids]
    
    corr1 <- cor(bioms,ff,method="pearson",use="complete.obs") 
    corr2 <- cor(bioms,ff,method="spearman",use="complete.obs") 
    
    corrall <- rbind(corrall,cbind(corr1,corr2))
  }
}

corm <- c(mean(corrall[,1],na.rm=T),mean(corrall[,2],na.rm=T))
corrall <- rbind(corrall,corm)

write.table(corrall,"rsign_ex_within/FW_corr_LC_new.csv",sep=",",row.names=F,col.names=F)

#####################################################################


