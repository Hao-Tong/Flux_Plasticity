### Correlation coefficient checking! 
### Further information: tonghao0605@gmail.com

dir <- "H:/mpidir/8.AlleleFlux/00_GxE/FC_FW"
setwd(dir)

#####################################################################

regr2o <- read.table("../FC_LNLC/rrBLUP/pearson_fcln.opt2ln.csv",head=F,sep=",")

aidall <- matrix(NA,336,150)

for (t in 1:50){
  
  for (p in 1:3){
  
  regr2 <- as.numeric(regr2o[(3*t+p-3),])
  aidi <- which(regr2>=regr2[336])
  aidall[1:length(aidi),(3*t+p-3)] <- aidi
  
  }
}

write.table(aidall,"rbiomass/numflux_model_LN_all.csv",sep=",",row.names=F,col.names=F)

#####################################################################

regr2o <- read.table("../FC_LNLC/rrBLUP/pearson_fclc.opt2lc.csv",head=F,sep=",")

aidall <- matrix(NA,336,150)

for (t in 1:50){
  
  for (p in 1:3){
    
    regr2 <- as.numeric(regr2o[(3*t+p-3),])
    aidi <- which(regr2>=regr2[336])
    aidall[1:length(aidi),(3*t+p-3)] <- aidi
    
  }
}

write.table(aidall,"rbiomass/numflux_model_LC_all.csv",sep=",",row.names=F,col.names=F)

#####################################################################

