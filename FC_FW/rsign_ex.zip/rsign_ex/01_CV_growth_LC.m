% Quadratic programming to estimate fluxes in metabolic network
% MOMA model for flux distributions
% Model details see below
% Contact: tonghao0605@gmail.com

% module load /apps/Modules/devel/Matlab-2020a

addpath(genpath('/winmounts/tong/winhome/MATLAB/glpk-4.48'));
addpath(genpath('/winmounts/tong/winhome/MATLAB/glpkmex'));
addpath(genpath('/winmounts/tong/winhome/MATLAB/opencobra-cobratoolbox-7be8e9b'));
changeCobraSolver('glpk');

addpath('/winmounts/tong/winhome/mpidir/8.AlleleFlux/00_GxE/FC_FW');
cd /winmounts/tong/winhome/mpidir/8.AlleleFlux/00_GxE/FC_FW/cvx/
cvx_setup

cd /winmounts/tong/winhome/mpidir/8.AlleleFlux/00_GxE/FC_FW

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % % % accession flux distribution in steady-state % % % % % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% nonzero flux only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

aramodel = readCbModel('ArabidopsisCoreModel.xml');

S = full(aramodel.S);
%[Srow Scol] = size(S);
c = aramodel.c.';
%n = Scol;

idnzero = csvread('nonzeroid.csv',0,0);

S = S(:,idnzero);
[Srow Scol] = size(S);
n = Scol;

c = c(idnzero);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% flux id 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
%%%%%% ALL FLUXES INCLUDED %%%%%%%%%%

fido = csvread('foldid.csv');
regr2o = csvread('../FC_LNLC/rrBLUP/pearson_fclc.opt2lc.csv');
%regido = csvread('regid_fluxbiom_min_qp_aa.csv');
%regid = regido(:,1);
regido = 1:336;

exid = 328:333;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% in cross-validation sets
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

aidinall = [];

for t = 1:50,

t

fid = fido(:,t);

fluxai = sprintf('../FC_LNLC/rrBLUP/predict_fclc.opt_rep_%d.csv', t);
fluxai = importdata(fluxai);
[fm fn] = size(fluxai);
fluxaiall = zeros(fm,n);
fluxaiall(:,regido) = fluxai;

%kk = zeros(n,1);
%kk(regido) = repelem(1,fn);

%kkf = diag(kk);

%regidcc = ismember(regid,regidr);
%regidc = find(regidcc==1);

%regr2 = regr2(regidc,1);
%regid = regid(regidc,1);

fluxai_sign = sprintf('../FC_LNLC/rrBLUP/predict_sign_fclc.opt_rep_%d.csv', t);
fluxai_sign = importdata(fluxai_sign);

for p = 1:3,


fidd = find(fid==p);

%%%%%% FLUXES PREDICTABILITY > biomass INCLUDED %%%%%%%%%%

regr2 = regr2o((3*t+p-3),:);
%aidi = find(regr2>=regr2(336));
aidi = 1:336;
Z = zeros(1,n);
Z(aidi) = 1; 
[aidim aidin] = size(aidi);

%aidi = csvread('3_rrBLUP_e/fluxpredict_cor_all.csv');
%aidi = aidi(1:176,1);

%aidiex = csvread('3_rrBLUP_e/fluxfrombiomass_compare_exclude_final.csv');
%aidiex = aidiex(:,2);
%aidii = [1:176].';
%aidi = setxor(aidiex,aidii);
  
%%% variable reactions
%aidi = [1:176].';

%aid = regid(aidi,:);
fluxa = fluxaiall(fidd,:);
[am an] = size(fluxa);
fluxai_signa = fluxai_sign(fidd,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% quadratic programming
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

carb = 6;
oxy = 61;
starch = 20;
suc = 31;

ccou = repelem(0,n);
ccou(carb) = 1;
ccou(oxy) = -3.81445;

ccol = repelem(0,n);
ccol(carb) = 1;
ccol(oxy) = -0.93815;

cssu = repelem(0,n);
cssu(starch) = 1;
cssu(suc) = -3.3694;

cssl = repelem(0,n);
cssl(starch) = 1;
cssl(suc) = -0.7898;

lb = [aramodel.lb(idnzero)];
ub = [aramodel.ub(idnzero)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

biofunco = csvread('biofunallaccfinal_LC.csv',0,0);
biofunc = biofunco(:,fidd);


fluxall = [];
SS = S;

for i= 1:am,

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SS(:,n) = biofunc(:,i);

Zs = Z.*fluxai_signa(i,:);
aidis = find(Zs==1);

A = 1./fluxa(i,:);
AA = Zs.*A;
AAn = AA(find(AA~=0));

lb(exid([1 2 3 4 5 6])) = fluxa(i,exid([1 2 3 4 5 6]))-fluxa(i,exid([1 2 3 4 5 6]))*0.2;
ub(exid([1 2 3 4 5 6])) = fluxa(i,exid([1 2 3 4 5 6]))+fluxa(i,exid([1 2 3 4 5 6]))*0.2;

clb = find(lb(exid([1 2 3 4 5 6]))<0);
cub = find(ub(exid([1 2 3 4 5 6]))>1000);
lb(exid(clb)) = 0;
ub(exid(cub)) = 1000;

b = 1; 

x = [];

cvx_begin quiet

	variable x(n);
	minimize(norm(AAn*x(aidis)-b));

	subject to

	SS*x == repelem(0,Srow).';	
	lb <= x <= ub;

	ccou*x <= 0;
	ccol*x >= 0;
	cssu*x <= 0;
	cssl*x >= 0;

	c*x >= 0;

cvx_end


fluxall = [fluxall,x];

end

fluxalli = sprintf('rsign_ex/steady-state_flux_LC_f%d_r%d.csv',t,p);
csvwrite(fluxalli,fluxall)

%aidinall = [aidinall;aidin];

%ffid = fopen(fluxalli,'w');
%fprintf(ffid,'%g\n',fluxall(1:549,:));
%fclose(ffid);

end

end

%csvwrite('rbiomass/numflux_model_LC.csv',aidinall);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



